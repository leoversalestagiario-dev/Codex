import { createHash } from 'node:crypto';
import { lstat, readFile } from 'node:fs/promises';
import { resolve, sep } from 'node:path';

export const sha256 = (data) => createHash('sha256').update(data).digest('hex');

/** Archive paths deliberately use POSIX separators on every operating system. */
export function validateRelativePath(path) {
  if (typeof path !== 'string' || !path || path.length > 1024 ||
      /[\\:\x00-\x1f\x7f<>"|?*]/.test(path) || path.startsWith('/') ||
      path.split('/').some((part) => !part || part === '.' || part === '..' || /[. ]$/.test(part))) {
    throw new Error(`Caminho inválido no manifesto: ${JSON.stringify(path)}`);
  }
  // Windows device names are not portable even when they have an extension.
  if (path.split('/').some((part) => /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) {
    throw new Error(`Nome reservado no manifesto: ${path}`);
  }
  return path;
}

export function validateManifest(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      value.schema_version !== 1 || value.algorithm !== 'sha256' ||
      !value.package || value.package.name !== 'guerra-dos-reinos' ||
      typeof value.package.version !== 'string' ||
      !/^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/.test(value.package.version) ||
      !Array.isArray(value.files) || value.files.length === 0 || value.files.length > 10000) {
    throw new Error('Manifesto de integridade inválido ou versão de schema não suportada.');
  }
  const seen = new Set();
  for (const entry of value.files) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new Error('Entrada de arquivo inválida no manifesto.');
    }
    validateRelativePath(entry.path);
    const key = entry.path.toLowerCase();
    if (seen.has(key) || key === 'package-integrity.json') {
      throw new Error(`Arquivo duplicado ou autorreferente no manifesto: ${entry.path}`);
    }
    seen.add(key);
    if (!Number.isSafeInteger(entry.size) || entry.size < 0 ||
        typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.sha256)) {
      throw new Error(`Tamanho ou SHA-256 inválido: ${entry.path}`);
    }
  }
  return value;
}

export function parseManifest(text) {
  if (typeof text !== 'string' || Buffer.byteLength(text) > 2 * 1024 * 1024) {
    throw new Error('Manifesto ausente ou acima do limite de 2 MiB.');
  }
  let value;
  try { value = JSON.parse(text); }
  catch { throw new Error('O manifesto de integridade não contém JSON válido.'); }
  return validateManifest(value);
}

export function createManifest(files, version) {
  const entries = [...files].map(([path, data]) => ({
    path: validateRelativePath(path), size: data.length, sha256: sha256(data),
  })).sort((a, b) => a.path.localeCompare(b.path, 'en'));
  return validateManifest({
    schema_version: 1,
    package: { name: 'guerra-dos-reinos', version },
    algorithm: 'sha256',
    files: entries,
  });
}

/** Check every component, including root, so a linked directory cannot escape it. */
export async function regularFile(root, relativePath) {
  validateRelativePath(relativePath);
  const base = resolve(root);
  const target = resolve(base, ...relativePath.split('/'));
  if (!target.startsWith(base + sep)) throw new Error('Arquivo fora da pasta do jogo.');
  const rootInfo = await lstat(base);
  if (!rootInfo.isDirectory() || rootInfo.isSymbolicLink()) {
    throw new Error('A pasta do jogo deve ser um diretório real, sem link simbólico.');
  }
  const parts = relativePath.split('/');
  let current = base;
  for (let index = 0; index < parts.length; index++) {
    current = resolve(current, parts[index]);
    const info = await lstat(current);
    if (info.isSymbolicLink()) throw new Error(`Link simbólico não permitido: ${relativePath}`);
    if (index === parts.length - 1 ? !info.isFile() : !info.isDirectory()) {
      throw new Error(`Caminho não é um arquivo regular: ${relativePath}`);
    }
  }
  return target;
}

export async function verifyManifestDirectory(root, manifest) {
  validateManifest(manifest);
  let bytes = 0;
  for (const entry of manifest.files) {
    let data;
    try { data = await readFile(await regularFile(root, entry.path)); }
    catch (error) { throw new Error(`Não foi possível verificar ${entry.path}: ${error.message}`); }
    if (data.length !== entry.size || sha256(data) !== entry.sha256) {
      throw new Error(`Integridade diferente da entrega: ${entry.path}. Extraia novamente o ZIP original.`);
    }
    bytes += data.length;
  }
  return { files: manifest.files.length, bytes, version: manifest.package.version };
}
