import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import {mkdir} from 'node:fs/promises';
const base=process.env.TEST_BASE||'http://127.0.0.1:3000';
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1080}});const errors=[];
 page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE',e.message);});
 page.setDefaultTimeout(20000);console.log('opening admin');
 await page.goto(`${base}/admin`);await page.locator('canvas').waitFor();console.log('canvas ready');await page.waitForFunction(()=>document.querySelector('#admin-status')?.textContent?.includes('teste'));
 console.log('connected');await page.getByRole('button',{name:'Nova rodada',exact:true}).click();
 await page.getByRole('button',{name:'Comentar “entrar”',exact:true}).click();await page.waitForFunction(()=>document.querySelector('#playerSelect')?.options.length===1);
 await page.getByRole('button',{name:'Comentar “entrar”',exact:true}).click();await page.waitForTimeout(200);
 assert.match(await page.locator('#queue-status').textContent(),/1 unidades vivas/);
 await page.getByRole('button',{name:'01 · Rose',exact:false}).click();await page.waitForFunction(()=>document.querySelector('#queue-status')?.textContent.includes('2 unidades vivas'));
 await page.getByRole('button',{name:'Repetir último evento',exact:true}).click();await page.waitForTimeout(250);assert.match(await page.locator('#queue-status').textContent(),/2 unidades vivas/);
 await page.getByRole('button',{name:'Combo Rose ×3',exact:true}).click();await page.waitForFunction(()=>document.querySelector('#queue-status')?.textContent.includes('5 unidades vivas'));
 await page.getByRole('button',{name:'+50 jogadores',exact:true}).click();await page.waitForFunction(()=>document.querySelector('#playerSelect')?.options.length===51);
 await page.waitForTimeout(2000);
 await mkdir('/tmp/guerra-artifacts',{recursive:true});await page.screenshot({path:'/tmp/guerra-artifacts/painel.png',fullPage:false});
 const audience=await browser.newPage({viewport:{width:608,height:1080}});audience.on('pageerror',e=>errors.push(e.message));await audience.goto(base);await audience.locator('canvas').waitFor();await audience.waitForTimeout(1500);assert.equal(await audience.locator('#controls').count(),0);assert.ok(await audience.locator('#ranking .rank').count()>0);await audience.screenshot({path:'/tmp/guerra-artifacts/batalha.png'});
 await page.getByRole('button',{name:'09 · Magic Potion',exact:false}).click();await page.waitForFunction(()=>document.querySelector('#overlay')?.textContent.includes('MAGIA ANCESTRAL'));await page.waitForFunction(()=>document.querySelector('#overlay')?.textContent.includes('VITÓRIA'),{timeout:10000});
 assert.match(await audience.locator('#overlay').textContent(),/VITÓRIA/);
 await page.waitForFunction(()=>document.querySelector('#overlay')?.hidden===true,{timeout:20000});
 assert.equal(await page.locator('#playerSelect option').count(),0);
 await page.getByRole('button',{name:'Pausar',exact:true}).click();await page.waitForFunction(()=>document.querySelector('#overlay')?.textContent.includes('PAUSADA'));
 assert.deepEqual(errors,[]);console.log('PASS browser: Phaser rendered, single life, 51 players, gifts, dedup, combo, supreme victory, auto restart, audience sync, pause; no JS errors.');
}finally{await browser.close();}
