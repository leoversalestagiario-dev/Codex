import { lstat, mkdir, readFile, readdir, rename, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateRawSync } from 'node:zlib';
import { randomUUID } from 'node:crypto';
import { createManifest, regularFile, sha256, validateRelativePath } from './manifest.mjs';

const rootFiles = [
  '.gitignore', '.npmrc', 'README.md', 'VERSION', 'package.json', 'package-lock.json',
  'tsconfig.json', 'index.html', 'INICIAR-JOGO.cmd', 'iniciar-jogo.sh',
  'content-manifest.json', 'config/gifts.json',
];
const folders = ['src', 'server', 'scripts', 'dist', 'docs', 'tests', 'public'];
const excluded = new Set([
  '.git', 'node_modules', '.npm-cache', '.cache', 'private', 'runs', 'artifacts',
  'test-results', 'playwright-report', '__pycache__', '.venv', 'downloads',
]);
function shouldExclude(path) {
  const parts = path.split('/');
  const name = parts.at(-1);
  return parts.some((part) => excluded.has(part)) ||
    /^\.env(?:\.|$)/.test(name) || /\.(?:key|pem|p12|pfx|log|tmp|bak)$/i.test(name) ||
    path === 'config/local.json' || name === 'package-integrity.json';
}

async function collectFiles(root) {
  const files = new Map();
  async function add(path) {
    if (shouldExclude(path)) return;
    const target = await regularFile(root, path);
    files.set(path, await readFile(target));
  }
  async function walk(path) {
    if (shouldExclude(path)) return;
    const info = await lstat(resolve(root, ...path.split('/')));
    if (info.isSymbolicLink()) throw new Error(`Pacote não aceita links simbólicos: ${path}`);
    if (info.isDirectory()) {
      for (const name of (await readdir(resolve(root, path))).sort()) {
        await walk(`${path}/${name}`);
      }
    } else if (info.isFile()) await add(path);
    else throw new Error(`Tipo de arquivo não suportado: ${path}`);
  }
  for (const path of rootFiles) await add(path);
  for (const folder of folders) {
    try { await lstat(resolve(root, folder)); }
    catch (error) {
      if (error.code === 'ENOENT' && ['docs', 'tests', 'public'].includes(folder)) continue;
      throw error;
    }
    await walk(folder);
  }
  if (!files.has('dist/index.html')) throw new Error('Execute npm run build antes de empacotar.');
  return files;
}

const crcTable = Array.from({ length: 256 }, (_, value) => {
  for (let bit = 0; bit < 8; bit++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});
function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 255];
  return (crc ^ 0xffffffff) >>> 0;
}

/** A deterministic, standard ZIP32 archive. Requires only Node, including on Windows. */
export function createZip(files) {
  if (files.size > 65535) throw new Error('Quantidade de arquivos excede ZIP32.');
  const local = [], central = [];
  let offset = 0;
  for (const [path, value] of [...files].sort(([a], [b]) => a.localeCompare(b, 'en'))) {
    validateRelativePath(path);
    const data = Buffer.from(value);
    const name = Buffer.from(`guerra-dos-reinos/${path}`, 'utf8');
    const compressed = deflateRawSync(data, { level: 9 });
    if (Math.max(data.length, compressed.length, offset) >= 0xffffffff) throw new Error('Pacote excede ZIP32.');
    const crc = crc32(data);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4); // Required ZIP version 2.0.
    header.writeUInt16LE(0x0800, 6); // UTF-8 names.
    header.writeUInt16LE(8, 8); // Raw DEFLATE.
    header.writeUInt16LE(33, 12); // 1980-01-01, reproducible metadata.
    header.writeUInt32LE(crc, 14);
    header.writeUInt32LE(compressed.length, 18);
    header.writeUInt32LE(data.length, 22);
    header.writeUInt16LE(name.length, 26);
    local.push(header, name, compressed);
    const directory = Buffer.alloc(46);
    directory.writeUInt32LE(0x02014b50, 0);
    directory.writeUInt16LE((3 << 8) | 20, 4); // Unix permission metadata.
    directory.writeUInt16LE(20, 6);
    directory.writeUInt16LE(0x0800, 8);
    directory.writeUInt16LE(8, 10);
    directory.writeUInt16LE(33, 14);
    directory.writeUInt32LE(crc, 16);
    directory.writeUInt32LE(compressed.length, 20);
    directory.writeUInt32LE(data.length, 24);
    directory.writeUInt16LE(name.length, 28);
    directory.writeUInt32LE(((path.endsWith('.sh') ? 0o100755 : 0o100644) << 16) >>> 0, 38);
    directory.writeUInt32LE(offset, 42);
    central.push(directory, name);
    offset += header.length + name.length + compressed.length;
  }
  const centralSize = central.reduce((size, buffer) => size + buffer.length, 0);
  if (offset + centralSize >= 0xffffffff) throw new Error('Pacote excede ZIP32.');
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.size, 8);
  end.writeUInt16LE(files.size, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, ...central, end]);
}

async function atomicWrite(path, data) {
  const temp = `${path}.${randomUUID()}.tmp`;
  await writeFile(temp, data);
  await rename(temp, path);
}

export async function packageProject(root, output) {
  root = resolve(root);
  output = resolve(output);
  const files = await collectFiles(root);
  const metadata = JSON.parse(files.get('package.json').toString('utf8'));
  if (metadata.name !== 'guerra-dos-reinos') throw new Error('Projeto não reconhecido.');
  if (files.get('VERSION').toString('utf8').trim() !== metadata.version) {
    throw new Error('VERSION e package.json precisam conter a mesma versão.');
  }
  const integrity = createManifest(files, metadata.version);
  files.set('package-integrity.json', Buffer.from(JSON.stringify(integrity, null, 2) + '\n'));
  const zip = createZip(files);
  const name = 'guerra-dos-reinos.zip';
  const hash = sha256(zip);
  const manifest = {
    schema_version: 1,
    name: metadata.name,
    version: metadata.version,
    minimum_node_major: 22,
    minimum_node_version: metadata.engines?.node || ">=22.12.0",
    packages: { 'node-cross-platform': { file: name, size: zip.length, sha256: hash } },
  };
  await mkdir(output, { recursive: true });
  await atomicWrite(resolve(output, name), zip);
  await atomicWrite(resolve(output, 'SHA256SUMS.txt'), `${hash}  ${name}\n`);
  await atomicWrite(resolve(output, 'release-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  return { path: resolve(output, name), files: files.size, bytes: zip.length, sha256: hash, version: metadata.version };
}

async function main() {
  const root = fileURLToPath(new URL('../', import.meta.url));
  let output = resolve(dirname(root), 'downloads');
  const args = process.argv.slice(2);
  for (let index = 0; index < args.length; index++) {
    if (args[index] !== '--output' || !args[index + 1]) {
      throw new Error('Uso: node scripts/package.mjs [--output pasta]');
    }
    output = resolve(args[++index]);
  }
  const result = await packageProject(root, output);
  console.log(`Pacote ${result.version}: ${result.path}\n${result.files} arquivos, ${result.bytes} bytes\nSHA-256: ${result.sha256}`);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => { console.error(error.message); process.exitCode = 1; });
}
