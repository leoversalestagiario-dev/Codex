export type Team = 'blue' | 'red';
export type Power = 'rose'|'gg'|'tiktok'|'rosa'|'tinyDiny'|'fingerHeart'|'doughnut'|'balloonGift'|'magicPotion';
export type Kind = 'soldier'|'archer'|'knight'|'dino';
export interface Player { id:string; name:string; team:Team; damage:number; kills:number }
export interface Unit { id:number; owner:string; name:string; team:Team; kind:Kind; main:boolean; x:number; y:number; hp:number; maxHp:number; damage:number; range:number; speed:number; cooldown:number; action:'walk'|'attack'|'hurt'|'dead'|'block'; death:number }
export interface Effect { id:number; type:string; team:Team; x:number; y:number; age:number; duration:number; name:string }
export interface Settings { castleHp:number; duration:number; unitHp:number; unitDamage:number; maxUnits:number }
export interface Snapshot { castleMaxHp:number; narration:{enabled:boolean;volume:number}; round:number; phase:'battle'|'cinematic'|'victory'; paused:boolean; remaining:number; nextRound:number; hp:Record<Team,number>; wins:Record<Team,number>; units:Unit[]; effects:Effect[]; players:Player[]; logs:string[]; lastGift:string; winner:Team|null; settings:Settings; queue:number; source:'test'|'tiktok'; connection:string }
export const powers:Record<Power,{name:string;label:string}> = {
 rose:{name:'Rose',label:'Reforço militar'},gg:{name:'GG',label:'Arqueiro'},tiktok:{name:'TikTok',label:'Cura do castelo'},rosa:{name:'Rosa',label:'Cavaleiro de elite'},tinyDiny:{name:'Tiny Diny',label:'Dinossauro de guerra'},fingerHeart:{name:'Finger Heart',label:'Três reforços'},doughnut:{name:'Doughnut',label:'Bênção de cura'},balloonGift:{name:'Balloon Gift',label:'Dragão de guerra'},magicPotion:{name:'Magic Potion',label:'Magia suprema'}
};
export const enemy = (t:Team):Team => t==='blue'?'red':'blue';
export const teamName = (t:Team) => t==='blue'?'REINO AZUL':'REINO VERMELHO';
