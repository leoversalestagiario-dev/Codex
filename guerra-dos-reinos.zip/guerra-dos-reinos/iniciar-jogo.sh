#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  echo 'Instale Node.js 22.12 ou superior: https://nodejs.org/' >&2
  exit 1
fi
exec node scripts/launcher.mjs "$@"
