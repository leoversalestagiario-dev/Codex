import http from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { Engine, GiftLedger } from './engine.js';
import { powers, type Power } from '../src/model.js';
import { TikTokBridge } from './tiktok.js';
const root=fileURLToPath(new URL('../',import.meta.url));
const {version}=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
const instanceId=crypto.randomUUID();
const engine=new Engine();const ledger=new GiftLedger();
const giftDefaults=JSON.parse(await readFile(resolve(root,'config/gifts.json'),'utf8'));
let local:any={};try{local=JSON.parse(await readFile(resolve(root,'config/local.json'),'utf8'));}catch{}
let gifts={...giftDefaults,...local.gifts};engine.configure(local.settings||{});engine.remaining=engine.settings.duration;engine.castleMaxHp=engine.settings.castleHp;engine.hp={blue:engine.settings.castleHp,red:engine.settings.castleHp};
const persist=()=>writeFile(resolve(root,'config/local.json'),JSON.stringify({gifts,settings:engine.settings},null,2));
const bridge=new TikTokBridge(engine,ledger,()=>gifts);
const production=process.env.NODE_ENV==='production';
const vite=production?null:await (await import('vite')).createServer({root,server:{middlewareMode:true},appType:'spa'});
const server=http.createServer(async(req,res)=>{
 if(req.url==='/api/health'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,service:"guerra-dos-reinos",version,instanceId,round:engine.round,phase:engine.phase,units:engine.units.length}));return;}
 if(vite){vite.middlewares(req,res);return;}
 try{
  const path=decodeURIComponent(new URL(req.url||'/', 'http://local').pathname);
  const target=path==='/'||path==='/admin'?resolve(root,'dist/index.html'):resolve(root,'dist',`.${path}`);
  if(!target.startsWith(resolve(root,'dist')+'/')){res.writeHead(403).end();return;}
  const data=await readFile(target);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml'} as Record<string,string>)[extname(target)]||'application/octet-stream');res.end(data);
 }catch{res.writeHead(404).end('Não encontrado');}
});
const wss=new WebSocketServer({noServer:true,maxPayload:16384});
server.on('upgrade',(req,socket,head)=>{
 if(req.url!=='/live'&&req.url!=='/control')return; // Vite handles its own HMR upgrades.
 const origin=req.headers.origin;
 if(origin&&new URL(origin).host!==req.headers.host){socket.destroy();return;}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
wss.on('connection',(ws,req)=>{
 const control=req.url==='/control';let lastBatch=0;
 ws.send(JSON.stringify({type:'config',gifts,catalog:bridge.catalog}));
 ws.send(JSON.stringify({type:'state',state:engine.snapshot()}));
 ws.on('message',async raw=>{
  if(!control)return;
  try{
   const m=JSON.parse(raw.toString());
   if(typeof m.type!=='string')return;
   const userId=typeof m.userId==='string'?m.userId.slice(0,80):'';
   const name=typeof m.name==='string'?m.name.slice(0,24):'Guerreiro';
   const test=engine.source==='test';
   switch(m.type){
    case 'join':if(test&&userId)engine.join(userId,name);break;
    case 'kill':if(test)engine.kill(userId);break;
    case 'gift':if(test&&userId&&Object.hasOwn(powers,m.power)){if(typeof m.eventId!=='string'||!m.eventId)return;const count=Number(m.count??1);const delta=ledger.accept(`test:${String(m.eventId).slice(0,160)}`,count,!!m.streak,m.ended!==false);if(delta)engine.gift(userId,m.power,delta);}break;
    case 'bots':if(test&&Date.now()-lastBatch>500){lastBatch=Date.now();for(let i=0;i<Math.min(50,Math.max(0,Number(m.count)||0));i++){const id=`bot-${crypto.randomUUID()}`;engine.join(id,`Guerreiro ${engine.players.size+1}`);}}break;
    case 'narration':if(typeof m.enabled==='boolean')engine.narration.enabled=m.enabled;if(typeof m.volume==='number'&&Number.isFinite(m.volume))engine.narration.volume=Math.min(1,Math.max(0,m.volume));break;
    case 'pause':engine.paused=!engine.paused;break;
    case 'reset':engine.reset();break;
    case 'destroy':if(test&&(m.team==='blue'||m.team==='red')){engine.hp[m.team as 'blue'|'red']=0;engine.win(m.team==='blue'?'red':'blue');}break;
    case 'settings':engine.configure(m.settings||{});await persist();break;
    case 'giftMap':{
     const next={...gifts};const ids=new Set<number>();
     for(const key of Object.keys(powers)){
      const id=m.ids?.[key];if(id!==null&&(!Number.isSafeInteger(id)||id<=0||ids.has(id)))throw Error('IDs precisam ser únicos e positivos.');
      if(id!==null){ids.add(id);const item=bridge.catalog.find(g=>g.id===id);if(!item||item.name.toLowerCase()!==powers[key as Power].name.toLowerCase())throw Error(`ID de ${powers[key as Power].name} não confere com o catálogo da live.`);}
      next[key]={...giftDefaults[key],id};
     }
     gifts=next;await persist();engine.log('Mapeamento de presentes salvo e conferido com o catálogo.');break;
    }
    case 'source':if(m.source==='test'){engine.source='test';bridge.stop();}else if(m.source==='tiktok'&&typeof m.username==='string'&&/^[\w.]{1,40}$/.test(m.username)){engine.source='tiktok';bridge.start(m.username);}break;
   }
   if(m.type==='giftMap'||m.type==='source')ws.send(JSON.stringify({type:'config',gifts,catalog:bridge.catalog}));
  }catch(e){engine.log(`Comando recusado: ${e instanceof Error?e.message:'entrada inválida'}`);}
 });
});
let last=performance.now();let broadcast=0;
setInterval(()=>{const now=performance.now();const dt=Math.min(.1,(now-last)/1000);last=now;engine.tick(dt);broadcast+=dt;if(broadcast>=.1){broadcast=0;const data=JSON.stringify({type:'state',state:engine.snapshot()});for(const ws of wss.clients)if(ws.readyState===WebSocket.OPEN&&ws.bufferedAmount<1024*1024)ws.send(data);}},1000/30);
setInterval(()=>{const data=JSON.stringify({type:'config',gifts,catalog:bridge.catalog});for(const ws of wss.clients)if(ws.readyState===WebSocket.OPEN)ws.send(data);},5000).unref();
const port=Number(process.env.PORT||3000);const host=process.env.HOST||'127.0.0.1';
server.listen(port,host,()=>console.log(`Guerra dos Reinos: porta ${port}. Público / • Painel /admin. Host ${host}`));
