import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { inflateRawSync } from 'node:zlib';

// These standalone JavaScript tools also run on Windows without a TS runtime.
const manifestModule = '../scripts/manifest.mjs';
const verifyModule = '../scripts/verify-package.mjs';
const packageModule = '../scripts/package.mjs';
const { createManifest, parseManifest, sha256, validateRelativePath } = await import(manifestModule);
const { verifyPackage } = await import(verifyModule);
const { packageProject } = await import(packageModule);

async function put(root: string, path: string, value: string | Buffer) {
  await mkdir(dirname(join(root, path)), { recursive: true });
  await writeFile(join(root, path), value);
}

test('manifesto verifica os arquivos extraídos e detecta alteração de conteúdo', async t => {
  const root = await mkdtemp(join(tmpdir(), 'guerra-integrity-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const files = new Map([
    ['README.md', Buffer.from('Guerra dos Reinos\n')],
    ['dist/index.html', Buffer.from('<html>Jogo</html>')],
  ]);
  for (const [path, data] of files) await put(root, path, data);
  await put(root, 'package-integrity.json', JSON.stringify(createManifest(files, '1.1.0')));
  assert.deepEqual(await verifyPackage(root), {
    files: 2, bytes: [...files.values()].reduce((total, value) => total + value.length, 0), version: '1.1.0',
  });
  // Installed dependencies and local user configuration are intentionally outside the delivery manifest.
  await put(root, 'config/local.json', '{}');
  assert.equal((await verifyPackage(root)).files, 2);
  await put(root, 'dist/index.html', '<html>Algo</html>');
  await assert.rejects(verifyPackage(root), /Integridade diferente.*dist\/index.html/);
});

test('manifestos malformados e caminhos que escapam do pacote são recusados', () => {
  assert.throws(() => parseManifest('{'), /JSON válido/);
  assert.throws(() => parseManifest('{}'), /Manifesto.*inválido/);
  const valid = createManifest(new Map([['README.md', Buffer.from('text')]]), '1.1.0');
  for (const path of ['../secret', '/etc/passwd', 'C:/secret', 'server\\private\\secret', 'a//b', './a', 'a/../b', 'CON.txt', 'a/b.', 'bad?.txt', 'bad*.txt', 'a|b.txt']) {
    assert.throws(() => validateRelativePath(path));
    const manifest = { ...valid, files: [{ ...valid.files[0], path }] };
    assert.throws(() => parseManifest(JSON.stringify(manifest)));
  }
  for (const entry of [
    { ...valid.files[0], sha256: 'PREENCHER_NA_RELEASE' },
    { ...valid.files[0], size: -1 },
    { ...valid.files[0], size: 0.5 },
  ]) assert.throws(() => parseManifest(JSON.stringify({ ...valid, files: [entry] })));
  assert.throws(() => parseManifest(JSON.stringify({ ...valid, files: [valid.files[0], { ...valid.files[0], path: 'readme.md' }] })), /duplicado/);
});

test('verificação recusa link simbólico mesmo quando o conteúdo tem hash válido', { skip: process.platform === 'win32' }, async t => {
  const root = await mkdtemp(join(tmpdir(), 'guerra-symlink-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const contents = Buffer.from('real');
  await put(root, 'real.txt', contents);
  await symlink(join(root, 'real.txt'), join(root, 'linked.txt'));
  await put(root, 'package-integrity.json', JSON.stringify(createManifest(new Map([['linked.txt', contents]]), '1.1.0')));
  await assert.rejects(verifyPackage(root), /Link simbólico/);
});

function readLocalZipFiles(zip: Buffer) {
  const files = new Map<string, Buffer>();
  let offset = 0;
  while (zip.readUInt32LE(offset) === 0x04034b50) {
    const compressedSize = zip.readUInt32LE(offset + 18);
    const nameSize = zip.readUInt16LE(offset + 26);
    const extraSize = zip.readUInt16LE(offset + 28);
    const nameStart = offset + 30;
    const dataStart = nameStart + nameSize + extraSize;
    const name = zip.subarray(nameStart, nameStart + nameSize).toString('utf8');
    files.set(name, inflateRawSync(zip.subarray(dataStart, dataStart + compressedSize)));
    offset = dataStart + compressedSize;
  }
  return files;
}

test('pacote contém jogo, manifesto e hashes reais, sem segredos ou caches', async t => {
  const temp = await mkdtemp(join(tmpdir(), 'guerra-delivery-'));
  t.after(() => rm(temp, { recursive: true, force: true }));
  const root = join(temp, 'project');
  const output = join(temp, 'delivery');
  for (const path of [
    '.gitignore', '.npmrc', 'README.md', 'package-lock.json', 'tsconfig.json', 'index.html',
    'INICIAR-JOGO.cmd', 'iniciar-jogo.sh', 'content-manifest.json', 'config/gifts.json',
    'src/main.ts', 'server/index.ts', 'scripts/launcher.mjs', 'dist/index.html',
    'docs/instalacao.md', 'tests/main.test.ts',
  ]) await put(root, path, `fixture ${path}\n`);
  await put(root, 'package.json', JSON.stringify({ name: 'guerra-dos-reinos', version: '1.1.0' }));
  await put(root, 'VERSION', '1.1.0\n');
  for (const path of ['.env', 'config/local.json', 'server/private/token.json', 'server/runs/run.log', 'node_modules/cache/index.js', 'server/runtime.key']) {
    await put(root, path, 'NOT FOR DISTRIBUTION');
  }
  const result = await packageProject(root, output);
  const zip = await readFile(result.path);
  assert.equal(result.sha256, sha256(zip));
  assert.match(await readFile(join(output, 'SHA256SUMS.txt'), 'utf8'), new RegExp(`^${result.sha256}  guerra-dos-reinos.zip`));
  const release = JSON.parse(await readFile(join(output, 'release-manifest.json'), 'utf8'));
  assert.equal(release.packages['node-cross-platform'].sha256, result.sha256);
  assert.equal(release.minimum_node_major, 22);
  const extracted = readLocalZipFiles(zip);
  assert.ok(extracted.has('guerra-dos-reinos/INICIAR-JOGO.cmd'));
  assert.ok(extracted.has('guerra-dos-reinos/dist/index.html'));
  assert.ok(extracted.has('guerra-dos-reinos/package-integrity.json'));
  assert.ok([...extracted.values()].every(data => !data.includes('NOT FOR DISTRIBUTION')));
  const restored = join(temp, 'restored');
  for (const [name, data] of extracted) await put(restored, name.slice('guerra-dos-reinos/'.length), data);
  assert.equal((await verifyPackage(restored)).files, extracted.size - 1);
  const again = await packageProject(root, output);
  assert.equal(again.sha256, result.sha256, 'same input yields a byte-identical archive');
});
