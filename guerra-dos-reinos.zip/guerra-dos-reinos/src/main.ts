import Phaser from 'phaser';
import { powers, teamName, type Power, type Snapshot, type Team, type Unit } from './model';
import './style.css';
const admin=location.pathname==='/admin';
const app=document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML=`${admin?'<aside id="controls"></aside>':''}<main id="stage"><div id="board"><div id="game"></div><header><div class="eyebrow"><span class="live-dot"></span> ARENA MEDIEVAL · AO VIVO</div><h1>GUERRA <small>DOS</small><br><strong>REINOS</strong></h1><div class="subtitle">DOIS REINOS. UMA COROA.</div><div id="score"></div><div class="castle-hud"><div class="blue"><b>REINO AZUL</b><div class="bar"><i id="bluebar"></i></div><span id="bluehp">2.500 / 2.500</span></div><div id="timer">03:00<small>RODADA 01</small></div><div class="red"><b>REINO VERMELHO</b><div class="bar"><i id="redbar"></i></div><span id="redhp">2.500 / 2.500</span></div></div></header><div id="battle-tag">A BATALHA PELO TRONO</div><section id="footer"><div id="army"></div><div class="join"><span>SEU REINO PRECISA DE VOCÊ</span><h2>DIGITE <em>ENTRAR</em><br>PARA GUERREAR</h2><p>Escolha seu destino. Defenda sua bandeira.</p></div><div class="rank-heading"><span>✦ GUERREIROS EM DESTAQUE</span><small>DANO TOTAL</small></div><div id="ranking"></div><div id="gift"><span>ÚLTIMO PRESENTE</span><b>Aguardando reforços…</b></div><div class="bottom-note"><span id="connection">CONECTANDO AO SERVIDOR</span><span id="fps">60 FPS</span></div></section><div id="overlay" hidden></div><div id="offline" hidden>Conexão interrompida • reconectando…</div><button id="sound" title="Ativar narração">♫ ATIVAR VOZ</button></div></main>`;
let state:Snapshot|undefined;let socket:WebSocket;let configuration:any={};let eventId='';let voice=false;let voiceUnlocked=false;let volume=.7;let previousRound=0;let previousPhase='';let previousGift='';let previousPlayers=0;const warned=new Set<string>();
const safe=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
function say(text:string){if(admin||!voice||!('speechSynthesis' in window))return;const u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.volume=volume;u.rate=1.05;const v=speechSynthesis.getVoices().find(v=>v.lang==='pt-BR');if(v)u.voice=v;speechSynthesis.speak(u);}
function connect(){socket=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/${admin?'control':'live'}`);socket.onopen=()=>{document.querySelector<HTMLElement>('#offline')!.hidden=true;};socket.onclose=()=>{document.querySelector<HTMLElement>('#offline')!.hidden=false;setTimeout(connect,1500);};socket.onmessage=event=>{const m=JSON.parse(event.data);if(m.type==='state'){state=m.state;renderHUD();}if(m.type==='config'){configuration=m;renderGiftConfig();}};}
function send(message:object){if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify(message));}
function renderHUD(){if(!state)return;const s=state;if(voice&&!s.narration.enabled&&'speechSynthesis' in window)speechSynthesis.cancel();voice=voiceUnlocked&&s.narration.enabled;volume=s.narration.volume;
 document.querySelector('#score')!.innerHTML=`<span class="blue">${s.wins.blue} <small>VITÓRIAS</small></span><i>⚔</i><span class="red">${s.wins.red} <small>VITÓRIAS</small></span>`;
 for(const t of ['blue','red'] as Team[]){document.querySelector(`#${t}hp`)!.textContent=`${Math.ceil(s.hp[t]).toLocaleString('pt-BR')} / ${s.castleMaxHp.toLocaleString('pt-BR')}`;document.querySelector<HTMLElement>(`#${t}bar`)!.style.width=`${s.hp[t]/s.castleMaxHp*100}%`;}
 const sec=Math.max(0,Math.ceil(s.remaining));document.querySelector('#timer')!.innerHTML=`${Math.floor(sec/60).toString().padStart(2,'0')}:${(sec%60).toString().padStart(2,'0')}<small>RODADA ${s.round.toString().padStart(2,'0')}</small>`;
 const counts=(team:Team)=>s.units.filter(u=>u.team===team&&u.hp>0).length;
 document.querySelector('#army')!.innerHTML=`<span class="blue">⚑ ${counts('blue')} GUERREIROS</span><b>VS</b><span class="red">${counts('red')} GUERREIROS ⚑</span>`;
 document.querySelector('#ranking')!.innerHTML=s.players.slice(0,5).map((p,i)=>`<div class="rank"><span class="position">0${i+1}</span><span class="team-dot ${p.team}"></span><b>${safe(p.name)}</b><span>${Math.round(p.damage).toLocaleString('pt-BR')} <small>⚔ ${p.kills}</small></span></div>`).join('')||'<div class="empty">O próximo herói pode ser você.<br>Comente entrar para participar.</div>';
 document.querySelector('#gift b')!.textContent=s.lastGift;document.querySelector('#connection')!.textContent=s.connection;
 const overlay=document.querySelector<HTMLElement>('#overlay')!;
 overlay.hidden=s.phase==='battle'&&!s.paused;
 if(s.phase==='victory')overlay.innerHTML=`<div class="victory ${s.winner}"><span>A COROA TEM UM NOVO DONO</span><div class="crown">♛</div><h2>VITÓRIA<br>${teamName(s.winner!)}</h2><p>${s.players[0]?`Herói da rodada: ${safe(s.players[0].name)}`:'Uma nova lenda começa.'}</p><b>Próxima batalha em ${Math.ceil(s.nextRound)}s</b></div>`;
 else if(s.phase==='cinematic')overlay.innerHTML=`<div class="cinematic"><span>PODER SUPREMO</span><h2>MAGIA ANCESTRAL</h2><p>Invocada por <b>${safe(s.effects.find(e=>e.type==='meteor')?.name||'um guerreiro')}</b></p></div>`;
 else if(s.paused)overlay.innerHTML='<div class="victory"><h2>BATALHA PAUSADA</h2></div>';
 if(previousRound!==s.round){say('Guerreiros, a batalha começou! Digitem entrar e defendam seus reinos!');previousRound=s.round;warned.clear();}
 if(s.phase==='victory'&&previousPhase!=='victory')say(`Vitória do ${teamName(s.winner!)}! Preparem-se para a próxima batalha!`);
 if(s.lastGift!==previousGift){if(s.lastGift.includes('Magic Potion'))say('Magia suprema! O castelo inimigo será destruído!');else if(s.lastGift.includes('Balloon Gift'))say('Um dragão foi invocado! O castelo inimigo está sob ataque!');else if(!s.lastGift.includes('Aguardando')&&!s.lastGift.includes('Nova rodada'))say('Reforços mágicos chegaram ao campo de batalha!');previousGift=s.lastGift;}
 if(s.players.length-previousPlayers>=10)say('Novos guerreiros chegaram! A guerra está ficando intensa!');previousPlayers=s.players.length;
 for(const t of ['blue','red'] as Team[])if(s.hp[t]>0&&s.hp[t]<s.castleMaxHp*.2&&!warned.has(t)){say(`O castelo do ${teamName(t)} está quase destruído!`);warned.add(t);}
 previousPhase=s.phase;
 if(admin)renderAdminState();
}
document.querySelector('#sound')!.addEventListener('click',()=>{voiceUnlocked=!voiceUnlocked;voice=voiceUnlocked&&(state?.narration.enabled??true);document.querySelector('#sound')!.textContent=voice?'♫ VOZ ATIVA':'♫ ATIVAR VOZ';if(voice)say('Guerra dos Reinos! A batalha espera por você.');else speechSynthesis.cancel();});
class Battlefield extends Phaser.Scene {
 ink!:Phaser.GameObjects.Graphics; labels=new Map<number,Phaser.GameObjects.Text>();ticks=0;
 create(){
  const bg=this.add.graphics();
  for(let y=0;y<1450;y+=4){const p=y/1450;bg.fillStyle(Phaser.Display.Color.GetColor(19+p*32,36+p*47,57+p*45));bg.fillRect(0,y,1080,4);}
  // Celestial halo and original, layered silhouette scenery.
  bg.fillStyle(0xf7d99a,.08);bg.fillCircle(800,580,130);bg.fillStyle(0xffe4ae,.6);bg.fillCircle(800,580,64);bg.fillStyle(0x344a62);bg.fillCircle(775,560,58);
  const mountain=(x:number,y:number,w:number,h:number,c:number)=>{bg.fillStyle(c);bg.fillTriangle(x-w,y+h,x,y,x+w,y+h);bg.fillStyle(0xb2c9ce,.2);bg.fillTriangle(x-w*.2,y+h*.25,x,y,x+w*.25,y+h*.3);};
  for(let i=0;i<9;i++)mountain(i*150,520+(i%3)*60,190,340,0x334d61);
  for(let i=0;i<7;i++)mountain(i*200-60,680+(i%2)*40,240,230,0x233f4c);
  bg.fillStyle(0x203c3b);bg.fillEllipse(440,920,1600,300);bg.fillStyle(0x29463b);bg.fillEllipse(800,1000,1600,320);
  for(let i=0;i<36;i++){const x=i*33;const y=850+Math.sin(i*1.8)*45;bg.fillStyle(0x18332f);bg.fillRect(x-3,y,6,100);for(let n=0;n<3;n++){bg.fillStyle(n%2?0x254737:0x1b3d34);bg.fillTriangle(x-25+n*3,y+65-n*18,x,y-30-n*18,x+25-n*3,y+65-n*18);}}
  bg.fillStyle(0x47513b);bg.fillEllipse(530,1150,1800,580);bg.fillStyle(0x64533d);bg.fillEllipse(540,1120,1500,350);bg.fillStyle(0x7b6649,.45);bg.fillEllipse(540,1100,1030,220);
  let seed=7;const rand=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  for(let i=0;i<220;i++){const x=rand()*1080,y=960+rand()*320;bg.fillStyle([0x8b7856,0x3f4f36,0x44513a][i%3],.5);bg.fillEllipse(x,y,3+rand()*9,2+rand()*5);}
  for(let i=0;i<38;i++){const x=rand()*1080,y=1180+rand()*140;bg.lineStyle(2,0x758047,.65);bg.lineBetween(x,y,x-5,y-13);bg.lineBetween(x,y,x+4,y-18);}
  bg.fillStyle(0x0b1727,.55);bg.fillRect(0,1310,1080,610);
  this.ink=this.add.graphics();
 }
 castle(g:Phaser.GameObjects.Graphics,x:number,team:Team,hp:number,time:number){
  const blue=team==='blue',color=blue?0x4ca9ee:0xf46667;const dark=blue?0x224d70:0x703b41;
  const rubble=hp<=0;const y=1040;
  g.fillStyle(0x101e26,.4);g.fillEllipse(x,y+17,250,45);
  if(rubble){for(let i=0;i<12;i++){g.fillStyle(i%2?0x69717a:0x858f99);g.fillRect(x-100+i*17,y-8-Math.sin(i*9)*10,22,24);}return;}
  g.fillStyle(0x5c6c7c);g.fillRect(x-82,y-190,164,195);g.fillStyle(0x8093a0);g.fillRect(x-75,y-188,150,15);
  for(const side of [-1,1]){const tx=x+side*85;g.fillStyle(0x738494);g.fillRoundedRect(tx-34,y-255,68,265,5);g.fillStyle(0x9aa8af);g.fillRect(tx-37,y-258,74,22);for(let k=0;k<4;k++)g.fillRect(tx-36+k*21,y-277,14,30);g.fillStyle(0x26394d);g.fillRoundedRect(tx-8,y-218,16,40,8);g.fillStyle(color);g.fillRect(tx-26,y-155,52,65);g.fillTriangle(tx-26,y-90,tx+26,y-90,tx,y-69);g.lineStyle(3,0xefce85);g.strokeRect(tx-20,y-149,40,48);g.fillStyle(0xefce85);g.fillCircle(tx,y-123,9);}
  g.lineStyle(2,0x344555,.4);for(let j=0;j<7;j++){g.lineBetween(x-72,y-165+j*26,x+72,y-165+j*26);for(let i=0;i<4;i++)g.lineBetween(x-70+i*42+(j%2?20:0),y-165+j*26,x-70+i*42+(j%2?20:0),y-139+j*26);}
  g.fillStyle(dark);g.fillRoundedRect(x-33,y-90,66,96,30);g.fillStyle(0x182332);g.fillRect(x-27,y-58,54,64);g.lineStyle(3,0xb29161);for(let i=0;i<4;i++)g.lineBetween(x-21+i*14,y-58,x-21+i*14,y+4);
  g.fillStyle(0x899aa6);g.fillRect(x-38,y-289,76,105);g.fillStyle(color);g.fillTriangle(x-56,y-287,x,y-346,x+56,y-287);g.fillStyle(0xffd682);g.fillCircle(x,y-257,12);g.fillStyle(dark);g.fillCircle(x,y-257,8);
  g.lineStyle(4,0xe5c68f);g.lineBetween(x,y-345,x,y-419);g.fillStyle(color);const flutter=Math.sin(time/350)*7;g.fillPoints([{x,y:y-419},{x:x+53,y:y-410+flutter},{x:x+48,y:y-377+flutter},{x,y:y-386}],true);
  for(const side of [-1,1]){const tx=x+side*45;g.fillStyle(0xffae46,.15);g.fillCircle(tx,y-52,24);g.fillStyle(0xf9aa49);g.fillTriangle(tx-5,y-50,tx+6,y-50,tx+Math.sin(time/90)*4,y-73);}
  if(hp<.2){g.fillStyle(0xff6d30,.7);for(let i=0;i<4;i++)g.fillTriangle(x-50+i*30,y-180,x-25+i*30,y-180,x-35+i*30,y-220-Math.sin(time/100+i)*18);}
 }
 warrior(g:Phaser.GameObjects.Graphics,u:Unit,time:number){
  const x=u.x,y=u.y,dir=u.team==='blue'?1:-1;const c=u.team==='blue'?0x409cde:0xdf555e;const shine=u.team==='blue'?0x8bd4ff:0xffa3a2;
  const walk=u.action==='walk'?Math.sin(time/115+u.id)*7:0;const dead=u.hp<=0;const lift=dead?20:Math.abs(walk)*.3;const yy=y-lift;
  g.fillStyle(0x111c24,dead?.12:.28);g.fillEllipse(x,y+8,u.kind==='dino'?80:43,13);
  if(dead){g.fillStyle(c,Math.max(0,1-u.death));g.fillRoundedRect(x-22,y-8,44,16,5);g.fillStyle(0xb4bfca,Math.max(0,1-u.death));g.fillCircle(x+dir*28,y-4,11);return;}
  if(u.kind==='dino'){
   g.lineStyle(12,c);g.lineBetween(x-dir*30,yy-13,x-dir*55,yy-35);g.fillStyle(c);g.fillEllipse(x,yy-30,85,52);g.fillRoundedRect(x+dir*18-18,yy-72,44,39,12);g.fillStyle(0xe8daae);g.fillRect(x+dir*18-12,yy-46,28,8);g.fillStyle(0x111b22);g.fillCircle(x+dir*34,yy-62,4);
   g.fillStyle(0x9aa4ac);g.fillEllipse(x-4,yy-43,49,20);g.lineStyle(10,c);g.lineBetween(x-20,yy-14,x-22+walk,yy+5);g.lineBetween(x+20,yy-14,x+22-walk,yy+5);
   g.fillStyle(0xe5c379);for(let i=0;i<5;i++)g.fillTriangle(x-36+i*13,yy-42,x-25+i*13,yy-42,x-31+i*13,yy-60);return;
  }
  const heavy=u.kind==='knight',size=heavy?1.2:1;
  g.lineStyle(8,0x26374b);g.lineBetween(x-7,yy-16,x-9+walk,yy+3);g.lineBetween(x+7,yy-16,x+9-walk,yy+3);g.lineStyle(7,0x182330);g.lineBetween(x-9+walk,yy+3,x-4+walk,yy+3);g.lineBetween(x+9-walk,yy+3,x+14-walk,yy+3);
  g.fillStyle(c);g.fillTriangle(x-13,yy-43,x+11,yy-43,x-dir*20,yy-9);g.fillStyle(heavy?0xa2aebd:0x70899e);g.fillRoundedRect(x-13*size,yy-44,26*size,32,6);g.fillStyle(c);g.fillRect(x-10,yy-35,20,17);g.lineStyle(3,0xe5c786);g.lineBetween(x-8,yy-23,x+8,yy-23);
  g.fillStyle(0xe4b68d);g.fillCircle(x,yy-54,10);g.fillStyle(0xb3c1cd);g.fillRoundedRect(x-12,yy-68,24,17,7);g.fillStyle(0x34495e);g.fillRect(x+dir*2-4,yy-59,9,4);g.fillStyle(shine);g.fillTriangle(x-5,yy-67,x+5,yy-67,x-dir*12,yy-83);
  const strike=u.action==='attack'?Math.sin(time/70)*16:0;
  if(u.kind==='archer'){
   g.lineStyle(3,0xe6ba76);g.beginPath();g.arc(x+dir*24,yy-38,19,-1.4,1.4,dir===-1);g.strokePath();g.lineStyle(1,0xf2e4bd);g.lineBetween(x+dir*28,yy-57,x+dir*28,yy-19);g.lineStyle(2,0xb7b3a0);g.lineBetween(x+dir*9,yy-37,x+dir*45,yy-37);
  }else{
   g.lineStyle(6,0x788fa0);g.lineBetween(x+dir*10,yy-37,x+dir*24,yy-31-strike);g.lineStyle(5,0xc7dbe2);g.lineBetween(x+dir*24,yy-35-strike,x+dir*(u.action==='attack'?56:35),yy-66-strike);g.lineStyle(4,0xe5bd67);g.lineBetween(x+dir*17,yy-38-strike,x+dir*31,yy-33-strike);
   g.fillStyle(0xe6ca87);g.fillPoints([{x:x-dir*11,y:yy-43},{x:x-dir*31,y:yy-41},{x:x-dir*29,y:yy-19},{x:x-dir*19,y:yy-11},{x:x-dir*10,y:yy-24}],true);g.fillStyle(c);g.fillCircle(x-dir*20,yy-29,8);g.fillStyle(shine);g.fillRect(x-dir*20-2,yy-35,4,13);
  }
  g.fillStyle(0x132331);g.fillRect(x-20,yy-91,40,5);g.fillStyle(c);g.fillRect(x-20,yy-91,40*u.hp/u.maxHp,5);
 }
 update(time:number){
  if(!state)return;const g=this.ink;g.clear();const s=state;
  this.castle(g,132,'blue',s.hp.blue/s.castleMaxHp,time);this.castle(g,948,'red',s.hp.red/s.castleMaxHp,time);
  const ids=new Set<number>();
  for(const u of [...s.units].sort((a,b)=>a.y-b.y)){
   this.warrior(g,u,time);ids.add(u.id);let text=this.labels.get(u.id);if(!text){text=this.add.text(0,0,'',{fontFamily:'Arial',fontSize:'15px',color:'#edf2ee',stroke:'#142136',strokeThickness:4}).setOrigin(.5);this.labels.set(u.id,text);}text.setText(u.name).setPosition(u.x,u.y-(u.kind==='dino'?94:109)).setAlpha(u.hp<=0?Math.max(0,1-u.death):1);
  }
  for(const [id,label] of this.labels)if(!ids.has(id)){label.destroy();this.labels.delete(id);}
  for(const e of s.effects){const p=e.age/e.duration;const color=e.team==='blue'?0x72d4ff:0xff8c86;
   if(e.type==='hit'){g.lineStyle(3,0xffe2aa,1-p);g.strokeCircle(e.x,e.y-30,p*35);}
   if(e.type==='heal'){g.lineStyle(4,0x92ffd1,1-p);g.strokeEllipse(e.x,e.y+150,70+p*220,30+p*90);for(let i=0;i<8;i++){const x=e.x+Math.sin(i*2)*75,y=e.y+140-p*200+i*12;g.fillStyle(0x9dffcd,1-p);g.fillRect(x-3,y-9,6,18);g.fillRect(x-9,y-3,18,6);}}
   if(e.type==='arrow'){g.lineStyle(3,0xf4d7a1,1-p);g.lineBetween(e.x-25,e.y-20,e.x+25,e.y-20);g.fillStyle(0xddddcc);g.fillTriangle(e.x+25,e.y-20,e.x+16,e.y-26,e.x+16,e.y-14);}
   if(e.type==='dragon'){
    const x=e.team==='blue'?-100+p*1300:1180-p*1300,y=650+Math.sin(p*10)*30;g.fillStyle(0x1a2732,.3);g.fillEllipse(x,1060,180,35);g.fillStyle(0x568265);g.fillEllipse(x,y,180,65);g.fillTriangle(x-40,y,x-170,y-70,x-70,y-20);g.fillStyle(0x8da375);const wing=Math.sin(time/85)*70;g.fillPoints([{x:x-20,y},{x:x-130,y:y-130-wing},{x:x-80,y:y-20-wing*.5},{x:x+35,y:y+15}],true);g.fillStyle(0x779367);g.fillRoundedRect(x+55,y-30,85,45,15);g.fillStyle(0xffd97a);g.fillCircle(x+109,y-18,6);
    for(let i=0;i<12;i++){g.fillStyle(i%2?0xffad44:0xff603d,.8*(1-i/15));g.fillCircle(x+135+i*8,y+12+i*17,10+i*2);}
   }
   if(e.type==='meteor'){
    g.fillStyle(0x070c20,.76);g.fillRect(0,440,1080,870);const portal=1+Math.sin(time/90)*.08;g.lineStyle(9,0xc99aff,.8);g.strokeEllipse(540,550,210*portal,70*portal);g.lineStyle(3,0x80efff);g.strokeEllipse(540,550,160*portal,48*portal);
    const q=Math.min(1,p*1.25),x=540+(e.x-540)*q,y=550+530*q;for(let i=10;i>=0;i--){g.fillStyle(i%2?0xffb854:0xff5c37,(1-i/12)*.8);g.fillCircle(x-i*(e.x-540)*.025,y-i*25,60-i*3);}g.fillStyle(0x4c3444);g.fillCircle(x,y,50);g.lineStyle(5,0xffcc7a);g.strokeCircle(x,y,52);
   }
  }
  if(++this.ticks%30===0)document.querySelector('#fps')!.textContent=`${Math.round(this.game.loop.actualFps)} FPS`;
 }
}
new Phaser.Game({type:Phaser.CANVAS,parent:'game',width:1080,height:1920,transparent:true,scene:Battlefield,render:{antialias:true},fps:{target:60},audio:{noAudio:true}});
function renderAdmin(){
 document.querySelector('#controls')!.innerHTML=`<div class="control-title"><span class="eyebrow">CENTRAL DE COMANDO</span><h2>Guerra dos Reinos<span>PAINEL DO STREAMER</span></h2><a href="/" target="_blank">Abrir tela do público ↗</a></div><div class="status-card"><i class="live-dot"></i><span id="admin-status">Conectando…</span></div><section><h3>01 <span>Comando da batalha</span></h3><div class="button-row"><button data-action="pause" id="pause">Pausar</button><button data-action="reset">Nova rodada</button></div><label>Vida dos castelos<input id="castleHp" type="number" value="2500" min="1" max="10000"></label><label>Duração em segundos<input id="duration" type="number" value="180" min="10" max="1800"></label><div class="button-row"><label>Vida dos guerreiros<input id="unitHp" type="number" value="100" min="1" max="10000"></label><label>Dano<input id="unitDamage" type="number" value="14" min="1" max="10000"></label></div><button id="settings">Salvar balanceamento</button><p class="hint">Vida e duração se aplicam na próxima rodada; atributos de unidades, nas próximas invocações.</p></section><section><h3>02 <span>Campo de testes</span></h3><label>Nome do espectador<input id="playerName" value="Arthur" maxlength="24"></label><div class="button-row"><button id="join" class="primary">Comentar “entrar”</button><button id="kill">Matar personagem</button></div><label>Jogador que envia o presente<select id="playerSelect"><option value="">Entre com um jogador primeiro</option></select></label><div class="button-row bots"><button data-bots="10">+10 jogadores</button><button data-bots="30">+30 jogadores</button><button data-bots="50">+50 jogadores</button></div><label>Quantidade por envio<input id="giftCount" type="number" value="1" min="1" max="10000"></label><div class="gift-grid">${(Object.keys(powers) as Power[]).map((p,i)=>`<button data-power="${p}"><span>0${i+1} · ${safe(powers[p].name)}</span><b>${safe(powers[p].label)}</b></button>`).join('')}</div><div class="button-row"><button id="duplicate">Repetir último evento</button><button id="combo">Combo Rose ×3</button></div><div class="button-row"><button data-destroy="blue">Destruir Azul</button><button data-destroy="red">Destruir Vermelho</button></div><p class="hint" id="queue-status">0 reforços na fila</p></section><section><h3>03 <span>Narração e transmissão</span></h3><button id="voice">Ativar / desativar voz</button><label>Volume<input id="volume" type="range" min="0" max="1" step=".05" value=".7"></label><label>Usuário TikTok (sem @)<input id="username" placeholder="seu_usuario" maxlength="40"></label><div class="button-row"><button id="testSource">Modo de teste</button><button id="liveSource">Conectar TikTok</button></div><p class="hint">O teste funciona sem internet após a instalação. O conector real depende de uma live ativa e acesso ao provedor. Nenhum ID é presumido.</p></section><section><h3>04 <span>Identificação de presentes</span></h3><p class="hint">Conecte à live, consulte o catálogo e preencha os IDs correspondentes. Rose e Rosa são poderes distintos. IDs são conferidos contra o nome exato do catálogo antes de salvar.</p><div id="gift-config"></div><button id="saveMap">Salvar IDs validados</button><details><summary>Catálogo da live</summary><div id="catalog">Nenhum catálogo recebido.</div></details></section><section><h3>05 <span>Registro da batalha</span></h3><div id="logs"></div></section><p class="hint">Capture apenas a aba do público no OBS / TikTok LIVE Studio. Este painel não deve aparecer na transmissão.</p>`;
 const input=(id:string)=>(document.getElementById(id) as HTMLInputElement).value;
 document.querySelectorAll<HTMLElement>('[data-action]').forEach(b=>b.onclick=()=>send({type:b.dataset.action}));
 document.querySelectorAll<HTMLElement>('[data-bots]').forEach(b=>b.onclick=()=>send({type:'bots',count:Number(b.dataset.bots)}));
 document.querySelectorAll<HTMLElement>('[data-destroy]').forEach(b=>b.onclick=()=>send({type:'destroy',team:b.dataset.destroy}));
 document.querySelector('#join')!.addEventListener('click',()=>{const name=input('playerName').trim();if(name)send({type:'join',userId:`test:${name.toLocaleLowerCase('pt-BR')}`,name});});
 document.querySelector('#kill')!.addEventListener('click',()=>send({type:'kill',userId:input('playerSelect')}));
 let lastGiftMessage:any;
 document.querySelectorAll<HTMLElement>('[data-power]').forEach(b=>b.onclick=()=>{eventId=crypto.randomUUID();lastGiftMessage={type:'gift',userId:input('playerSelect'),power:b.dataset.power,count:Number(input('giftCount')),eventId};send(lastGiftMessage);});
 document.querySelector('#duplicate')!.addEventListener('click',()=>{if(lastGiftMessage)send(lastGiftMessage);});
 document.querySelector('#combo')!.addEventListener('click',()=>{const id=crypto.randomUUID();const base={type:'gift',userId:input('playerSelect'),power:'rose',eventId:id,streak:true};send({...base,count:1,ended:false});send({...base,count:3,ended:false});lastGiftMessage={...base,count:3,ended:true};send(lastGiftMessage);});
 document.querySelector('#settings')!.addEventListener('click',()=>send({type:'settings',settings:Object.fromEntries(['castleHp','duration','unitHp','unitDamage'].map(k=>[k,Number(input(k))]))}));
 document.querySelector('#voice')!.addEventListener('click',()=>send({type:'narration',enabled:!state?.narration.enabled}));
 document.querySelector('#volume')!.addEventListener('input',()=>{volume=Number(input('volume'));send({type:'narration',volume});});
 document.querySelector('#testSource')!.addEventListener('click',()=>send({type:'source',source:'test'}));
 document.querySelector('#liveSource')!.addEventListener('click',()=>send({type:'source',source:'tiktok',username:input('username').trim().replace(/^@/,'')}));
 document.querySelector('#saveMap')!.addEventListener('click',()=>send({type:'giftMap',ids:Object.fromEntries(Object.keys(powers).map(p=>[p,input(`map-${p}`)?Number(input(`map-${p}`)):null]))}));
}
let lastPlayerList='';let filledSettings=false;
function renderAdminState(){if(!state)return;
 document.querySelector('#admin-status')!.textContent=state.connection;
 document.querySelector('#voice')!.textContent=state.narration.enabled?'Narração ativada · desativar':'Narração desativada · ativar';
 document.querySelector('#pause')!.textContent=state.paused?'Continuar':'Pausar';
 document.querySelector('#queue-status')!.textContent=`${state.queue} reforços na fila · ${state.units.filter(u=>u.hp>0).length} unidades vivas · fonte: ${state.source}`;
 document.querySelector('#logs')!.innerHTML=state.logs.map(s=>`<p>${safe(s)}</p>`).join('');
 const list=state.players.map(p=>p.id).join('|');
 if(lastPlayerList!==list){const select=document.querySelector<HTMLSelectElement>('#playerSelect')!;const selected=select.value;select.innerHTML=state.players.map(p=>`<option value="${safe(p.id)}">${safe(p.name)} · ${p.team==='blue'?'Azul':'Vermelho'}</option>`).join('');if(state.players.some(p=>p.id===selected))select.value=selected;lastPlayerList=list;}
 if(!filledSettings){for(const k of ['castleHp','duration','unitHp','unitDamage'] as const)(document.getElementById(k) as HTMLInputElement).value=String(state.settings[k]);filledSettings=true;}
}
function renderGiftConfig(){if(!admin)return;const el=document.querySelector('#gift-config')!;
 if(!el.childElementCount)el.innerHTML=Object.entries(powers).map(([p,v])=>`<label>${safe(v.name)}<input id="map-${p}" type="number" min="1" placeholder="ID conferido na live" value="${configuration.gifts?.[p]?.id||''}"></label>`).join('');
 document.querySelector('#catalog')!.innerHTML=(configuration.catalog||[]).map((g:any)=>`<p>${Number(g.id)} · ${safe(String(g.name))}</p>`).join('')||'Nenhum catálogo recebido.';
}
if(admin)renderAdmin();
function fit(){const board=document.querySelector<HTMLElement>('#board')!;const stage=document.querySelector<HTMLElement>('#stage')!;const scale=Math.min(stage.clientWidth/1080,innerHeight/1920);board.style.transform=`scale(${scale})`;stage.style.setProperty('--board-width',`${1080*scale}px`);}
window.addEventListener('resize',fit);fit();connect();
