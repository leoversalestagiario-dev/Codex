import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import type { AddressInfo } from 'node:net';
import { readHealth, parseOptions, supportedNode } from '../scripts/launcher.mjs';

async function healthFixture(body: unknown, status = 200) {
  const server = createServer((_req, res) => {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(body));
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const url = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  try { return await readHealth(url); }
  finally { await new Promise<void>(resolve => server.close(() => resolve())); }
}

test('inicializador recusa serviço alheio e servidor antigo sem identidade', async () => {
  assert.equal((await healthFixture({ ok: true })).kind, 'busy');
  assert.equal((await healthFixture({ ok: true, service: 'outro-jogo' })).kind, 'busy');
  assert.equal((await healthFixture({ message: 'not found' }, 404)).kind, 'busy');
});

test('inicializador identifica serviço e versão antes de reutilizar processo', async () => {
  assert.deepEqual(await healthFixture({ ok: true, service: 'guerra-dos-reinos', version: '1.1.0' }), { kind: 'game', version: '1.1.0' });
});

test('porta inválida e argumentos desconhecidos não chegam ao sistema operacional', () => {
  assert.deepEqual(parseOptions(['--port', '3001', '--no-open'], {}), { port: 3001, open: false });
  for (const port of ['0', '65536', '-1', '3000 & other', '', '3.14']) {
    assert.throws(() => parseOptions(['--port', port], {}));
  }
  assert.throws(() => parseOptions(['--port'], {}));
  assert.throws(() => parseOptions(['--execute'], {}));
});

test('runtime mínimo acompanha o Vite: Node 22.12 ou posterior', () => {
  for (const version of ['20.19.0','21.7.0','22.0.0','22.11.9']) assert.equal(supportedNode(version), false);
  for (const version of ['22.12.0','22.13.0','24.19.0']) assert.equal(supportedNode(version), true);
});
