import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseManifest, regularFile, verifyManifestDirectory } from './manifest.mjs';

export async function verifyPackage(root, { manifestPath = 'package-integrity.json' } = {}) {
  const path = await regularFile(root, manifestPath);
  const manifest = parseManifest(await readFile(path, 'utf8'));
  return verifyManifestDirectory(root, manifest);
}

async function main() {
  let root = fileURLToPath(new URL('../', import.meta.url));
  const args = process.argv.slice(2);
  for (let index = 0; index < args.length; index++) {
    if (args[index] !== '--root' || !args[index + 1]) {
      throw new Error('Uso: node scripts/verify-package.mjs [--root pasta-extraida]');
    }
    root = resolve(args[++index]);
  }
  const result = await verifyPackage(root);
  console.log(`Integridade conferida: Guerra dos Reinos ${result.version}, ${result.files} arquivos (${result.bytes} bytes).`);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => { console.error(error.message); process.exitCode = 1; });
}
