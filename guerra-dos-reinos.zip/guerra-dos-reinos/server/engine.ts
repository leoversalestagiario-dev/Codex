import { enemy, powers, type Effect, type Kind, type Player, type Power, type Settings, type Snapshot, type Team, type Unit } from '../src/model.js';
export class Engine {
 settings:Settings={castleHp:2500,duration:180,unitHp:100,unitDamage:14,maxUnits:100};
 castleMaxHp=2500;
 narration={enabled:true,volume:.7};
 round=1; phase:Snapshot['phase']='battle'; paused=false; remaining=180; nextRound=0;
 hp:Record<Team,number>={blue:2500,red:2500}; wins={blue:0,red:0}; winner:Team|null=null;
 players=new Map<string,Player>(); units:Unit[]=[]; effects:Effect[]=[]; logs:string[]=[]; lastGift='Aguardando o primeiro presente';
 queue:{owner:string;kind:Kind;main:boolean}[]=[]; serial=0; cinematic=0; supreme:Team|null=null;
 source:Snapshot['source']='test'; connection='Modo de teste • offline';
 log(s:string){this.logs.unshift(s);this.logs=this.logs.slice(0,60);}
 effect(type:string,team:Team,x:number,y:number,duration=1,name=''){this.effects.push({id:++this.serial,type,team,x,y,age:0,duration,name});}
 join(id:string,name:string){
  if(this.phase!=='battle')return false;
  if(this.units.some(u=>u.owner===id&&u.main&&u.hp>0)||this.queue.some(u=>u.owner===id&&u.main))return false;
  let p=this.players.get(id);
  if(!p){const blue=[...this.players.values()].filter(p=>p.team==='blue').length;const red=this.players.size-blue;p={id,name:name.slice(0,24),team:blue<=red?'blue':'red',damage:0,kills:0};this.players.set(id,p);}
  this.spawn(id,'soldier',true);this.log(`${p.name} entrou no ${p.team==='blue'?'Azul':'Vermelho'}`);return true;
 }
 spawn(owner:string,kind:Kind,main=false){
  if(this.units.filter(u=>u.hp>0).length>=this.settings.maxUnits){this.queue.push({owner,kind,main});return;}
  const p=this.players.get(owner);if(!p)return;
  const factor=kind==='knight'?3:kind==='dino'?5:1;
  this.units.push({id:++this.serial,owner,name:main?p.name:kind==='archer'?'Arqueiro':kind==='knight'?'Cavaleiro':kind==='dino'?'Dino':`Guarda · ${p.name}`,team:p.team,kind,main,x:p.team==='blue'?130:950,y:720+Math.random()*460,hp:this.settings.unitHp*factor,maxHp:this.settings.unitHp*factor,damage:this.settings.unitDamage*factor,range:kind==='archer'?240:kind==='dino'?105:55,speed:kind==='knight'?55:65+Math.random()*15,cooldown:Math.random()*.6,action:'walk',death:0});
 }
 kill(owner:string){for(const u of this.units)if(u.owner===owner&&u.main){u.hp=0;u.action='dead';}}
 gift(owner:string,power:Power,count=1){
  const p=this.players.get(owner);if(!p){this.log('Presente ignorado: o usuário precisa comentar entrar nesta rodada.');return false;}
  if(this.phase!=='battle'){this.log('Presente fora da batalha: nenhuma habilidade ativada.');return false;}
  this.lastGift=`${p.name} · ${powers[power].name} ×${count}`;this.log(this.lastGift);
  for(let i=0;i<count;i++){
   if(power==='rose')this.spawn(owner,'soldier');
   if(power==='gg')this.spawn(owner,'archer');
   if(power==='rosa')this.spawn(owner,'knight');
   if(power==='tinyDiny')this.spawn(owner,'dino');
   if(power==='fingerHeart')for(let j=0;j<3;j++)this.spawn(owner,'soldier');
   if(power==='tiktok'||power==='doughnut'){
    this.hp[p.team]=Math.min(this.castleMaxHp,this.hp[p.team]+(power==='tiktok'?20:200));
    if(power==='doughnut')for(const u of this.units)if(u.team===p.team&&u.hp>0&&Math.abs(u.x-(p.team==='blue'?130:950))<350)u.hp=Math.min(u.maxHp,u.hp+80);
    this.effect('heal',p.team,p.team==='blue'?105:975,780,2,p.name);
   }
   if(power==='balloonGift'){
    this.effect('dragon',p.team,540,630,4,p.name);
    for(const u of this.units)if(u.team!==p.team&&u.hp>0)this.hit(u,130,owner);
    this.castleDamage(enemy(p.team),450,owner);
   }
   if(power==='magicPotion'){
    this.phase='cinematic';this.cinematic=4;this.supreme=p.team;
    this.effect('meteor',p.team,p.team==='blue'?940:140,700,4,p.name);
    this.log(`MAGIA SUPREMA! ${p.name} invocou o meteoro!`);break;
   }
  }
  return true;
 }
 hit(u:Unit,damage:number,owner:string){
  const real=Math.min(u.hp,damage);u.hp=Math.max(0,u.hp-damage);u.action=u.hp<=0?'dead':'hurt';
  const p=this.players.get(owner);if(p){p.damage+=real;if(u.hp<=0)p.kills++;}
  this.effect('hit',u.team,u.x,u.y-.5,0.4,`−${Math.round(real)}`);
 }
 castleDamage(team:Team,n:number,owner:string){const damage=Math.min(this.hp[team],n);this.hp[team]-=damage;const p=this.players.get(owner);if(p)p.damage+=damage;this.effect('hit',team,team==='blue'?100:980,720,.7,`−${Math.round(damage)}`);if(this.hp[team]<=0)this.win(enemy(team));}
 win(t:Team){if(this.phase==='victory')return;this.phase='victory';this.winner=t;this.wins[t]++;this.nextRound=15;this.queue=[];this.log(`VITÓRIA DO REINO ${t==='blue'?'AZUL':'VERMELHO'}!`);}
 reset(){this.round++;this.phase='battle';this.remaining=this.settings.duration;this.nextRound=0;this.castleMaxHp=this.settings.castleHp;this.hp={blue:this.castleMaxHp,red:this.castleMaxHp};this.players.clear();this.units=[];this.effects=[];this.queue=[];this.winner=null;this.supreme=null;this.lastGift='Nova rodada • comente entrar';this.log(`Rodada ${this.round}: a batalha começou!`);}
 configure(s:Partial<Settings>){for(const key of ['castleHp','duration','unitHp','unitDamage'] as const){const v=s[key];if(typeof v==='number'&&Number.isFinite(v))this.settings[key]=Math.max(key==='duration'?10:1,Math.min(v,key==='duration'?1800:10000));}}
 tick(dt:number){
  if(this.paused)return;
  for(const e of this.effects)e.age+=dt;this.effects=this.effects.filter(e=>e.age<e.duration);
  if(this.phase==='victory'){this.nextRound-=dt;if(this.nextRound<=0)this.reset();return;}
  if(this.phase==='cinematic'){this.cinematic-=dt;if(this.cinematic<=0&&this.supreme){this.hp[enemy(this.supreme)]=0;this.win(this.supreme);}return;}
  this.remaining-=dt;
  if(this.remaining<=0){let t:Team=this.hp.blue>this.hp.red?'blue':'red';if(this.hp.blue===this.hp.red){const damage=(team:Team)=>[...this.players.values()].filter(p=>p.team===team).reduce((a,p)=>a+p.damage,0);t=damage('blue')>damage('red')?'blue':damage('blue')<damage('red')?'red':this.round%2?'blue':'red';this.log('Desempate: dano total; igualdade final alterna o reino por rodada.');}this.win(t);return;}
  for(const u of this.units){
   if(u.hp<=0){u.death+=dt;continue;}
   u.cooldown-=dt;u.action='walk';
   let target:Unit|undefined;let best=Infinity;
   for(const v of this.units){if(v.team===u.team||v.hp<=0)continue;const distance=Math.hypot(v.x-u.x,v.y-u.y);if(distance<best){best=distance;target=v;}}
   const castleX=u.team==='blue'?950:130;
   if(target&&best<320){
    if(best<=u.range){u.action='attack';if(u.cooldown<=0){u.cooldown=1;const blocked=Math.random()<.15;target.action=blocked?'block':'hurt';if(u.kind==='archer')this.effect('arrow',u.team,(u.x+target.x)/2,(u.y+target.y)/2,.4);this.hit(target,u.damage*(blocked?.4:1),u.owner);if(u.kind==='dino')for(const v of this.units)if(v!==target&&v.team!==u.team&&v.hp>0&&Math.hypot(v.x-target.x,v.y-target.y)<100)this.hit(v,u.damage*.5,u.owner);}}
    else{u.x+=(target.x-u.x)/best*u.speed*dt;u.y+=(target.y-u.y)/best*u.speed*dt;}
   }else if(Math.abs(u.x-castleX)>u.range){u.x+=Math.sign(castleX-u.x)*u.speed*dt;}
   else{u.action='attack';if(u.cooldown<=0){u.cooldown=1;this.castleDamage(enemy(u.team),u.damage,u.owner);if(this.phase!=='battle')break;}}
  }
  // Soft separation keeps formations readable instead of stacking all warriors on one pixel.
  const alive=this.units.filter(u=>u.hp>0);
  for(let i=0;i<alive.length;i++)for(let j=i+1;j<alive.length;j++){
   const a=alive[i],b=alive[j];let dx=a.x-b.x,dy=a.y-b.y;const distance=Math.hypot(dx,dy),space=a.kind==='dino'||b.kind==='dino'?52:35;
   if(distance<space){if(distance<.01){dx=i%2?1:-1;dy=1;}const d=Math.hypot(dx,dy),push=(space-distance)*Math.min(1,dt*5)*.5;a.x+=dx/d*push;b.x-=dx/d*push;a.y+=dy/d*push;b.y-=dy/d*push;}
  }
  for(const u of alive){u.x=Math.max(105,Math.min(975,u.x));u.y=Math.max(760,Math.min(1220,u.y));}
  this.units=this.units.filter(u=>u.death<1.2);
  while(this.queue.length&&this.units.filter(u=>u.hp>0).length<this.settings.maxUnits){const q=this.queue.shift()!;this.spawn(q.owner,q.kind,q.main);}
 }
 snapshot():Snapshot{return {castleMaxHp:this.castleMaxHp,narration:this.narration,round:this.round,phase:this.phase,paused:this.paused,remaining:this.remaining,nextRound:this.nextRound,hp:this.hp,wins:this.wins,units:this.units,effects:this.effects,players:[...this.players.values()].sort((a,b)=>b.damage-a.damage),logs:this.logs,lastGift:this.lastGift,winner:this.winner,settings:this.settings,queue:this.queue.length,source:this.source,connection:this.connection};}
}
// Combo counters are cumulative. Only a final streak event commits a gift; IDs survive round resets.
export class GiftLedger {
 seen=new Map<string,number>();
 accept(id:string,count:number,streak:boolean,ended:boolean){
  if(!id||!Number.isSafeInteger(count)||count<1||count>10000)return 0;
  if(streak&&!ended)return 0;
  const previous=this.seen.get(id)||0;if(count<=previous)return 0;
  this.seen.set(id,count);return count-previous;
 }
}
