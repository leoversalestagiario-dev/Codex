import { spawn } from 'node:child_process';
import { readFile, mkdir, access } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const service = 'guerra-dos-reinos';

export function supportedNode(version) {
  const [major, minor] = String(version).split('.').map(Number);
  return major > 22 || (major === 22 && minor >= 12);
}

export function parseOptions(args, env = process.env) {
  let port = env.PORT || '3000';
  let open = true;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--no-open') open = false;
    else if (args[i] === '--port') port = args[++i];
    else throw new Error(`Opção desconhecida: ${args[i]}`);
  }
  if (!/^\d+$/.test(String(port)) || Number(port) < 1 || Number(port) > 65535) {
    throw new Error('A porta precisa ser um número entre 1 e 65535.');
  }
  return { port: Number(port), open };
}

export async function readHealth(base) {
  try {
    const response = await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(1500) });
    if (!response.ok) return { kind: 'busy' };
    const body = await response.json().catch(() => null);
    if (body?.ok !== true || body?.service !== service) return { kind: 'busy' };
    return { kind: 'game', version: body.version };
  } catch (error) {
    if (error?.cause?.code === 'ECONNREFUSED') return { kind: 'empty' };
    throw new Error('Não foi possível verificar a porta local. Confira firewall e outros programas.', { cause: error });
  }
}

export async function dependenciesReady(root) {
  try {
    const pkg = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'));
    const lock = JSON.parse(await readFile(resolve(root, 'package-lock.json'), 'utf8'));
    for (const name of Object.keys({ ...pkg.dependencies, ...pkg.devDependencies })) {
      const installed = JSON.parse(await readFile(resolve(root, 'node_modules', name, 'package.json'), 'utf8'));
      if (installed.version !== lock.packages?.[`node_modules/${name}`]?.version) return false;
    }
    return true;
  } catch { return false; }
}

function runNpm(args, root) {
  return new Promise((resolveRun, reject) => {
    // The Windows shell receives only these fixed npm commands, never user input.
    const child = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', args, {
      cwd: root, stdio: 'inherit', shell: process.platform === 'win32',
    });
    child.once('error', reject);
    child.once('exit', code => code === 0 ? resolveRun() : reject(new Error(`npm ${args[0]} terminou com código ${code}.`)));
  });
}

function openBrowser(url) {
  const [command, args] = process.platform === 'win32'
    ? ['rundll32.exe', ['url.dll,FileProtocolHandler', url]]
    : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  const browser = spawn(command, args, { stdio: 'ignore', detached: true });
  browser.on('error', () => console.log(`Abra o navegador manualmente: ${url}`));
  browser.unref();
}

export async function main(args = process.argv.slice(2), root = projectRoot) {
  if (!supportedNode(process.versions.node)) throw new Error('Instale Node.js 22.12 ou superior em https://nodejs.org/ e tente novamente.');
  const { port, open } = parseOptions(args);
  const pkg = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'));
  console.log(`Guerra dos Reinos ${pkg.version}`);

  let hasIntegrity = true;
  try { await access(resolve(root, 'package-integrity.json')); }
  catch (e) { if (e.code === 'ENOENT') hasIntegrity = false; else throw e; }
  if (hasIntegrity) {
    const { verifyPackage } = await import('./verify-package.mjs');
    await verifyPackage(root);
    console.log('Integridade do pacote conferida.');
  }

  const base = `http://127.0.0.1:${port}`;
  const health = await readHealth(base);
  if (health.kind === 'busy') throw new Error(`A porta ${port} está ocupada por outro programa ou uma versão antiga sem identificação. Feche esse programa ou execute com --port 3001.`);
  if (health.kind === 'game') {
    if (health.version !== pkg.version) throw new Error(`A versão ${health.version} já está aberta nessa porta. Feche a janela anterior antes de iniciar ${pkg.version}.`);
    console.log('O jogo já está em execução.');
    if (open) openBrowser(`${base}/admin`);
    return;
  }

  if (!await dependenciesReady(root)) {
    console.log('Primeira preparação: instalando as dependências. Esta etapa precisa de internet.');
    await runNpm(['ci', '--no-audit', '--no-fund'], root);
  }
  try { await access(resolve(root, 'dist/index.html')); }
  catch {
    console.log('Preparando a tela do jogo…');
    await runNpm(['run', 'build'], root);
  }

  const logs = resolve(root, 'server/runs');
  await mkdir(logs, { recursive: true });
  const log = createWriteStream(resolve(logs, 'launcher.log'), { flags: 'a' });
  log.write(`\n${new Date().toISOString()} Guerra dos Reinos ${pkg.version}\n`);
  const child = spawn(process.execPath, ['--import', 'tsx', 'server/start.ts'], {
    cwd: root,
    env: { ...process.env, HOST: '127.0.0.1', PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', data => { process.stdout.write(data); log.write(data); });
  child.stderr.on('data', data => { process.stderr.write(data); log.write(data); });
  let exitCode = null;
  let childError;
  child.once('error', error => { childError = error; });
  child.once('exit', (code, signal) => { exitCode = code ?? (signal ? 1 : 0); });
  const stop = () => child.kill('SIGTERM');
  process.once('SIGINT', stop);
  process.once('SIGTERM', stop);
  try {
    let ready = false;
    for (let attempt = 0; attempt < 120; attempt++) {
      if (childError) throw childError;
      if (exitCode !== null) throw new Error(`O servidor encerrou durante a inicialização (${exitCode}). Veja server/runs/launcher.log.`);
      await delay(250);
      const current = await readHealth(base);
      if (current.kind === 'game' && current.version === pkg.version) { ready = true; break; }
      if (current.kind === 'busy') throw new Error('Outro programa ocupou a porta durante a inicialização.');
    }
    if (!ready) throw new Error('O servidor não ficou pronto em 30 segundos. Veja server/runs/launcher.log.');
    console.log(`\nJogo pronto. Painel: ${base}/admin\nTela do público: ${base}/\nMantenha esta janela aberta. Ctrl+C encerra o servidor.\nNo painel, clique em +10 jogadores para testar a batalha.`);
    if (open) openBrowser(`${base}/admin`);
    const code = await new Promise((resolveExit, reject) => {
      if (exitCode !== null) { resolveExit(exitCode); return; }
      child.once('exit', (code, signal) => resolveExit(signal === 'SIGTERM' ? 0 : code ?? 1));
      child.once('error', reject);
    });
    if (code !== 0) throw new Error(`O servidor encerrou com código ${code}.`);
  } finally {
    if (exitCode === null) stop();
    process.removeListener('SIGINT', stop);
    process.removeListener('SIGTERM', stop);
    log.end();
  }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch(error => {
    console.error(`\nNão foi possível abrir o jogo: ${error.message}`);
    process.exitCode = 1;
  });
}
