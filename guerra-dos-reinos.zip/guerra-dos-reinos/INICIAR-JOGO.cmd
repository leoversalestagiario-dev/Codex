@echo off
setlocal
cd /d "%~dp0"
title Guerra dos Reinos
where node >nul 2>nul
if errorlevel 1 (
  echo Instale o Node.js 22.12 ou superior em https://nodejs.org/
  echo Depois feche esta janela e abra INICIAR-JOGO.cmd novamente.
  pause
  exit /b 1
)
node scripts\launcher.mjs
if errorlevel 1 (
  echo.
  echo O jogo nao iniciou. Leia a mensagem acima.
  pause
  exit /b 1
)
endlocal
