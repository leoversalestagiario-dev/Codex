import { Engine, GiftLedger } from './engine.js';
import type { Power } from '../src/model.js';
// API from zerodytrash/TikTok-Live-Connector, pinned by package-lock.json.
// Do not interpret names as identifiers or enable unaudited IDs.
export class TikTokBridge {
 catalog:{id:number;name:string}[]=[];
 private connection:any;private timer:ReturnType<typeof setTimeout>|undefined;private generation=0;private username='';private attempt=0;
 constructor(private engine:Engine,private ledger:GiftLedger,private getGifts:()=>Record<Power,{id:number|null;name:string}>){ }
 stop(){this.generation++;clearTimeout(this.timer);this.timer=undefined;this.catalog=[];this.connection?.disconnect();this.connection=null;this.engine.connection='Modo de teste • offline';}
 start(username:string){this.stop();this.username=username;this.attempt=0;void this.connect(this.generation);}
 private retry(generation:number){if(generation!==this.generation||this.timer)return;const delay=Math.min(60000,2000*2**this.attempt++);this.engine.connection=`Reconectando em ${delay/1000}s`;this.timer=setTimeout(()=>{this.timer=undefined;void this.connect(generation);},delay);}
 private async connect(generation:number){
  if(generation!==this.generation)return;
  this.connection?.removeAllListeners();this.connection?.disconnect();this.connection=null;
  this.engine.connection='Conectando ao TikTok…';
  try{
   const {TikTokLiveConnection,WebcastEvent,ControlEvent}=await import('tiktok-live-connector');
   if(generation!==this.generation)return;
   const key=process.env.EULER_API_KEY;
   const c=new TikTokLiveConnection(this.username,{processInitialData:false,enableExtendedGiftInfo:true,...(key?{signApiKey:key}:{})});this.connection=c;
   c.on(WebcastEvent.CHAT,(data:any)=>{if(generation!==this.generation)return;const id=String(data.user?.userId||'');if(id&&id!=='0'&&String(data.comment).trim().toLowerCase()==='entrar')this.engine.join(id,String(data.user?.nickname||data.user?.uniqueId||'Guerreiro'));});
   c.on(WebcastEvent.GIFT,(data:any)=>{
    if(generation!==this.generation)return;
    const id=String(data.user?.userId||'');const giftId=Number(data.giftId);const map=this.getGifts();const power=(Object.keys(map) as Power[]).find(k=>map[k].id===giftId);
    if(!power){this.engine.log(`Presente não mapeado: ID ${giftId}`);return;}
    if(!this.catalog.some(g=>g.id===giftId&&g.name.toLowerCase()===map[power].name.toLowerCase())){this.engine.log('ID não validado no catálogo da live.');return;}
    const streak=Number(data.giftDetails?.giftType??data.gift?.type??data.giftType)===1;
    const eventId=String(streak?data.groupId||'':data.common?.msgId||'');
    if(!id||id==='0'||!eventId||eventId==='0'){this.engine.log('Presente sem identidade estável: processamento recusado.');return;}
    const delta=this.ledger.accept(`tiktok:${this.username}:${id}:${giftId}:${eventId}`,Number(data.repeatCount||1),streak,!!data.repeatEnd);
    if(delta)this.engine.gift(id,power,delta);
   });
   c.on(ControlEvent.DISCONNECTED,()=>{if(generation===this.generation)this.retry(generation);});
   c.on(ControlEvent.ERROR,()=>{if(generation===this.generation){this.engine.log('Erro no conector TikTok. Confira live, rede e credenciais do provedor.');this.retry(generation);}});
   await c.connect();if(generation!==this.generation){c.disconnect();return;}
   this.attempt=0;clearTimeout(this.timer);this.timer=undefined;
   const list:any=await c.fetchAvailableGifts();
   if(generation!==this.generation)return;
   this.catalog=(Array.isArray(list)?list:[]).map((g:any)=>({id:Number(g.id),name:String(g.name)}));
   this.engine.connection=`TikTok conectado · @${this.username} · ${this.catalog.length} presentes`;
   this.engine.log('Catálogo obtido. Confira e associe os nove IDs no painel antes de ativar presentes.');
  }catch{if(generation===this.generation){this.engine.log('Não foi possível conectar: live offline, acesso ao provedor ou rede indisponível.');this.retry(generation);}}
 }
}
